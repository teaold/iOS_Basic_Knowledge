//
//  MightyCrash.m
//  LYFix
//
//  Created by YZY on 2018/11/16.
//  Copyright © 2018 Xly. All rights reserved.
//

#import "MightyCrash.h"

@implementation MightyCrash

- (float)divideUsingDenominator:(NSInteger)denominator {
    return 1.f/denominator;
}
@end
