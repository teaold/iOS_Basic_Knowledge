//
//  AppDelegate.h
//  CC_VideoToolBoxLearning_1
//
//  Created by CC老师 on 2017/6/26.
//  Copyright © 2017年 Miss CC. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

